# Read the Iris dataset from the CSV file
iris_data <- read.csv("Iris.csv")

# Calculate summary statistics for Sepal Length
sepal_length_mean <- mean(iris_data$SepalLengthCm)
sepal_length_median <- median(iris_data$SepalLengthCm)
sepal_length_range <- range(iris_data$SepalLengthCm)
sepal_length_variance <- var(iris_data$SepalLengthCm)
sepal_length_stddev <- sd(iris_data$SepalLengthCm)

# Calculate summary statistics for Sepal Width
sepal_width_mean <- mean(iris_data$SepalWidthCm)
sepal_width_median <- median(iris_data$SepalWidthCm)
sepal_width_range <- range(iris_data$SepalWidthCm)
sepal_width_variance <- var(iris_data$SepalWidthCm)
sepal_width_stddev <- sd(iris_data$SepalWidthCm)

# Calculate summary statistics for Petal Length
petal_length_mean <- mean(iris_data$PetalLengthCm)
petal_length_median <- median(iris_data$PetalLengthCm)
petal_length_range <- range(iris_data$PetalLengthCm)
petal_length_variance <- var(iris_data$PetalLengthCm)
petal_length_stddev <- sd(iris_data$PetalLengthCm)

# Calculate summary statistics for Petal Width
petal_width_mean <- mean(iris_data$PetalWidthCm)
petal_width_median <- median(iris_data$PetalWidthCm)
petal_width_range <- range(iris_data$PetalWidthCm)
petal_width_variance <- var(iris_data$PetalWidthCm)
petal_width_stddev <- sd(iris_data$PetalWidthCm)

# Print the summary statistics
cat("Sepal Length Mean:", sepal_length_mean, "\n")
cat("Sepal Length Median:", sepal_length_median, "\n")
cat("Sepal Length Range:", sepal_length_range, "\n")
cat("Sepal Length Variance:", sepal_length_variance, "\n")
cat("Sepal Length Standard Deviation:", sepal_length_stddev, "\n\n")

cat("Sepal Width Mean:", sepal_width_mean, "\n")
cat("Sepal Width Median:", sepal_width_median, "\n")
cat("Sepal Width Range:", sepal_width_range, "\n")
cat("Sepal Width Variance:", sepal_width_variance, "\n")
cat("Sepal Width Standard Deviation:", sepal_width_stddev, "\n\n")

cat("Petal Length Mean:", petal_length_mean, "\n")
cat("Petal Length Median:", petal_length_median, "\n")
cat("Petal Length Range:", petal_length_range, "\n")
cat("Petal Length Variance:", petal_length_variance, "\n")
cat("Petal Length Standard Deviation:", petal_length_stddev, "\n\n")

cat("Petal Width Mean:", petal_width_mean, "\n")
cat("Petal Width Median:", petal_width_median, "\n")
cat("Petal Width Range:", petal_width_range, "\n")
cat("Petal Width Variance:", petal_width_variance, "\n")
cat("Petal Width Standard Deviation:", petal_width_stddev, "\n")
